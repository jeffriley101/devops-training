WOODShed WOODCHUCK NEWSLETTER TEMPLATE

Included:
- Editable Word newsletter template
- Email-ready HTML newsletter template
- Approved Woodshed Camp masthead artwork
- Woodshed app QR code

Reusable modules:
1. Headline + short introduction
2. Four-item feature callout rail
3. Practice Insight with metrics + Practice Chart Minutes
4. Optional update / dates / spotlight module
5. Call to Action with OPEN WOODSHED button + QR

Brand rules:
- Keep the Woodshed Camp artwork as the masthead.
- Keep the single content grid and square-corner blocks.
- Use deep forest green, cream, sage, and gold.
- Keep one clear headline and one primary CTA.
- Delete modules that are not needed rather than filling the page with filler.
- For email, keep body copy at roughly 15px or larger.
