VIKING SAX LOGO SUITE

PRIMARY FULL LOGO
- Primary_Master_3000: print/layout master raster; transparent background; 300 DPI metadata.
- Primary_Web_1200: website, brochure, digital marketing.
- Primary_Email_600: newsletters, email, documents.
- Primary_UI_512: medium digital placements.
- Social_Profile_1080: square white-background social/profile artwork.

COMPACT SYMBOL
- Symbol_512 / 256 / 128: small UI, app/site icon concepts, social avatar situations
  where the full VIKING SAX wordmark would become too small.

ONE COLOR
- OneColor_1200: simplified forest-green mark for stamps, embroidery concepts,
  single-ink printing, or vendor reference.

IMPORTANT
This suite is derived from the approved raster logo. It is not a true vector master.
For permanent trademark/large-format production, create a professionally traced SVG/EPS/PDF vector master.
